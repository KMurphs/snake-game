//Setup
const arr = [3, 4, 5, 6, 7, 8]

// Snippet 1
arr.forEach((item) => {
    console.log(item);
})

// Snippet 2
for(let i = 0; i < arr.length; i++){
    console.log(arr[i])
}