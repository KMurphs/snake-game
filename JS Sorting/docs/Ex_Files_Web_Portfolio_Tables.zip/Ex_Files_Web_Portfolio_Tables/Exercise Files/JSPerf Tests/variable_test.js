//Setup

// Snippet 1
const doc = document.body;
const div1 = document.createElement("DIV");
const div2 = document.createElement("DIV");
doc.appendChild(div1)
doc.appendChild(div2)

// Snippet 2
document.body.appendChild(document.createElement("DIV"))
document.body.appendChild(document.createElement("DIV"))